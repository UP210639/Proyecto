import Logo from "./Logo.png"
export {default as Logo2} from "./Logo2.png"
export {default as LogImage2} from "./Login2.jpg"
export {default as LogImage} from "./Login.png"

export default Logo;