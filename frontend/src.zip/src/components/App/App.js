import './App.css';
import NavBar from '../NavBar'
import Main from '../Main/Main';

function App() {


  return (
    <div>
        <NavBar /> 
        <Main />
    </div>
  );
}

export default App;
